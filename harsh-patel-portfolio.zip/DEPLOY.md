# Deploying Harsh Patel's Portfolio

This portfolio is a **100% static React app**. It has **no backend and no database**
at runtime — the contact form opens the visitor's own email app via `mailto:`,
and the resume is just a PDF file.

You can host it on any of these **for free**:

| Host             | Cost | Difficulty | Notes                                        |
|------------------|------|------------|----------------------------------------------|
| GitHub Pages     | Free | Easy       | Great for GitHub users                       |
| Netlify          | Free | Easiest    | Drag-and-drop the `build/` folder            |
| Vercel           | Free | Easy       | Connects to a GitHub repo in 1 click         |
| Cloudflare Pages | Free | Easy       | Fastest global CDN                           |
| GoDaddy shared   | Paid | Easy       | Upload `build/` contents to `public_html/`   |

---

## Everything you need is already in `/app/frontend`

Only folder that matters for deployment: **`/app/frontend`**.
You can ignore `/app/backend` — the live site does not use it.

---

## Option A — GitHub Pages (recommended for your friend)

There are two flavors of GitHub Pages. Pick ONE:

### A1. User site — `https://<username>.github.io`

Use this if the friend doesn't already have a user page.

1. Create a new **public** repo named **exactly** `<username>.github.io`
   (e.g., `hp0413174.github.io`).
2. Clone it locally, then copy everything from `/app/frontend` into the repo root.
3. In `package.json`, **no changes needed** — the site will be served from the domain root.
4. Install & build:
   ```bash
   yarn install
   yarn build
   ```
5. Install the one-line deploy helper:
   ```bash
   yarn add --dev gh-pages
   ```
6. Open `package.json` and add these two lines inside `"scripts"`:
   ```json
   "predeploy": "yarn build",
   "deploy": "gh-pages -d build -b main"
   ```
   Also add at the top level:
   ```json
   "homepage": "https://<username>.github.io"
   ```
7. Deploy:
   ```bash
   yarn deploy
   ```
8. In GitHub → repo → **Settings → Pages** → set "Source" to **Deploy from a branch**,
   pick **`main`** branch and **`/ (root)`** folder.
9. Visit `https://<username>.github.io` — live in under 2 minutes.

### A2. Project site — `https://<username>.github.io/<repo>`

Use this if your friend already has a user page and wants this under a sub-path
(e.g. `hp0413174.github.io/portfolio`).

Everything is identical to A1 **except**:

- In `package.json`, set:
  ```json
  "homepage": "https://<username>.github.io/<repo-name>"
  ```
- And the deploy script uses the `gh-pages` branch:
  ```json
  "deploy": "gh-pages -d build"
  ```
- In GitHub → Settings → Pages → set Source to **`gh-pages`** branch, `/ (root)`.

> The app already uses `process.env.PUBLIC_URL` for the resume link,
> so the PDF download keeps working under any sub-path.

---

## Option B — Netlify (easiest, no CLI)

1. In `/app/frontend`, run:
   ```bash
   yarn install
   yarn build
   ```
2. Open https://app.netlify.com/drop
3. Drag the entire **`build/`** folder onto the page.
4. You get a live `https://<random>.netlify.app` URL. Point your custom domain later if you like.

---

## Option C — Vercel

1. Push `/app/frontend` to any GitHub repo.
2. Go to https://vercel.com/new → import the repo.
3. Vercel auto-detects Create React App. Click **Deploy**. Done.

---

## Option D — GoDaddy / any cPanel shared host

1. In `/app/frontend`, run `yarn install && yarn build`.
2. Log into cPanel → **File Manager** → `public_html/`.
3. Upload **everything inside** `build/` (not the folder itself).
   That means `index.html`, `static/`, `Harsh_Patel_Resume.pdf`, and any assets.
4. Visit your domain — done.

---

## Handing the project to a friend

Zip the `/app/frontend` folder (or let them clone the repo if you push it).
They only need:

- **Node.js 18+** (https://nodejs.org)
- **Yarn**: `npm install -g yarn`

Then:

```bash
cd frontend
yarn install
yarn build
```

…and follow any of the options above.

They do **not** need:
- A database
- A backend server
- Python / FastAPI
- Any API keys
- SMTP credentials
- A third-party form service account

---

## After deployment — things that "just work"

| Feature                        | Works? | Why                                                   |
|--------------------------------|--------|-------------------------------------------------------|
| Contact form → open email app  | Yes    | `mailto:` is native browser behavior                  |
| "Copy email" button            | Yes    | Uses the browser Clipboard API                        |
| Download Resume (PDF)          | Yes    | PDF is bundled in the build                           |
| Google Fonts (IBM Plex)        | Yes    | Fetched from Google CDN                               |
| Hero photo                     | Yes    | Hosted on Emergent CDN (no domain restrictions)       |
| LinkedIn / GitHub links        | Yes    | Plain external URLs                                   |

---

## One-time things to update before shipping

Open `/app/frontend/src/data/mock.js` and double-check:

- `profile.contact.email`     (currently `hp0413174@gmail.com`)
- `profile.contact.phone`     (currently `+1 (216) 551-1536`)
- `profile.contact.linkedin`
- `profile.contact.github`    (currently `https://github.com/hp0413174-harsh`)

To replace the resume PDF, drop the new file at
`frontend/public/Harsh_Patel_Resume.pdf` (keep the same filename to avoid
touching code).

---

## Need to go even simpler?

If the friend has never used a terminal, tell them:

1. Install Node.js (one download).
2. Open the folder in terminal: `cd frontend`
3. Run `yarn && yarn build`
4. Drag the `build` folder to https://app.netlify.com/drop
5. Copy the URL Netlify gives them. That's the live site.

That's the end-to-end MVP path — about 5 minutes total.

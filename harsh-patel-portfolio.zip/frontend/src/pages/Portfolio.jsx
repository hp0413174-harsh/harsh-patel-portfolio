import React, { useEffect } from "react";
import Navbar from "../components/portfolio/Navbar";
import Hero from "../components/portfolio/Hero";
import About from "../components/portfolio/About";
import KeywordBar from "../components/portfolio/KeywordBar";
import ITSkills from "../components/portfolio/ITSkills";
import ExperienceSection from "../components/portfolio/ExperienceSection";
import ITProjects from "../components/portfolio/ITProjects";
import Certifications from "../components/portfolio/Certifications";
import DevSkills from "../components/portfolio/DevSkills";
import DevProjects from "../components/portfolio/DevProjects";
import Education from "../components/portfolio/Education";
import Testimonials from "../components/portfolio/Testimonials";
import Contact from "../components/portfolio/Contact";
import Footer from "../components/portfolio/Footer";

const Portfolio = () => {
  useEffect(() => {
    document.title = "Harsh Patel — IT Support Specialist & Web Developer";
    // Fade-in observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("visible");
            observer.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll(".fade-in").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <main className="min-h-screen bg-[#faf8f4] text-[#161616]">
      <Navbar />
      <Hero />
      <KeywordBar />
      <About />

      {/* IT SUPPORT — TOP */}
      <ITSkills />
      <ExperienceSection variant="it" />
      <ITProjects />
      <Certifications />

      {/* WEB DEVELOPMENT — BOTTOM */}
      <DevSkills />
      <ExperienceSection variant="dev" />
      <DevProjects />
      <Education />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
};

export default Portfolio;

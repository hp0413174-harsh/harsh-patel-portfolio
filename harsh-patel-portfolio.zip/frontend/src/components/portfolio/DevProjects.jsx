import React from "react";
import { devProjects } from "../../data/mock";
import { Layers, ArrowUpRight } from "lucide-react";
import { Badge } from "../ui/badge";

const DevProjects = () => {
  return (
    <section id="dev-projects" className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">08 &mdash; Selected Work</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            Web Development Projects
          </h2>
          <p className="mt-5 text-[17px] leading-[1.8] text-[#3a3a3a]">
            Representative work spanning e-commerce, healthcare and e-learning — each built with
            performance, accessibility and clean design systems in mind.
          </p>
        </div>

        <div className="mt-12 grid lg:grid-cols-3 gap-6">
          {devProjects.map((p, i) => (
            <article
              key={p.title}
              className="fade-in group bg-[#faf8f4] border border-[#e0dcd2] rounded-sm p-7 flex flex-col hover:border-[#1e3a5f] hover:shadow-[0_10px_30px_-15px_rgba(30,58,95,0.25)] transition-all duration-300"
            >
              <div className="flex items-start justify-between">
                <div className="w-11 h-11 rounded-sm bg-[#1e3a5f] text-[#faf8f4] flex items-center justify-center">
                  <Layers className="w-5 h-5" />
                </div>
                <span className="mono text-xs text-[#8a8a8a] tracking-widest">
                  0{i + 1}
                </span>
              </div>
              <h3 className="mt-5 font-serif text-xl text-[#161616] leading-tight">{p.title}</h3>
              <p className="mt-1 text-sm text-[#6b6b6b]">{p.subtitle}</p>

              <ul className="mt-5 space-y-2.5 flex-1">
                {p.bullets.map((b, idx) => (
                  <li key={idx} className="flex gap-2.5 text-[14px] text-[#3a3a3a] leading-relaxed">
                    <span className="text-[#1e3a5f] mono text-xs mt-[5px]">&#9656;</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-6 pt-5 border-t border-[#eeeadf]">
                <div className="flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <Badge key={t} variant="outline" className="border-[#d4cfc0] text-[#3a3a3a] bg-white font-normal rounded-sm text-[11px] uppercase tracking-wider mono">
                      {t}
                    </Badge>
                  ))}
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-[#1e3a5f] group-hover:gap-3 transition-all">
                  <span className="mono uppercase tracking-widest text-xs">Case study</span>
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DevProjects;

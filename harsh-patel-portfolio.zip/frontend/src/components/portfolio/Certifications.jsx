import React from "react";
import { certifications } from "../../data/mock";
import { Award } from "lucide-react";

const statusStyles = {
  Completed: "bg-[#1e3a5f] text-[#faf8f4]",
  "In Progress": "bg-[#f2efe8] text-[#1e3a5f] border border-[#1e3a5f]",
  Planned: "bg-white text-[#6b6b6b] border border-[#d4cfc0]",
};

const Certifications = () => {
  return (
    <section id="certifications" className="py-20 lg:py-28 bg-[#161616] text-[#e5e0d6]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="mono text-xs tracking-[0.18em] uppercase text-[#8ca9c9]">
            05 &mdash; Continuous Learning
          </div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#faf8f4]">
            Certifications & Credentials
          </h2>
          <div className="w-16 h-[2px] bg-[#8ca9c9] mt-4"></div>
          <p className="mt-5 text-[17px] leading-[1.8] text-[#b8b8b8]">
            Industry-recognized certifications focused on IT operations, networking and modern
            front-end engineering — actively being earned to stay sharp.
          </p>
        </div>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {certifications.map((c) => (
            <div
              key={c.name}
              className="fade-in bg-[#1f1f1f] border border-[#2a2a2a] rounded-sm p-6 hover:border-[#8ca9c9] transition-colors duration-300"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
                <span className={`text-[10px] mono uppercase tracking-widest px-2.5 py-1 rounded-sm ${statusStyles[c.status] || statusStyles.Planned}`}>
                  {c.status}
                </span>
              </div>
              <h3 className="mt-4 font-serif text-lg text-[#faf8f4] leading-tight">{c.name}</h3>
              <div className="mt-1 text-sm text-[#8a8a8a]">{c.issuer}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;

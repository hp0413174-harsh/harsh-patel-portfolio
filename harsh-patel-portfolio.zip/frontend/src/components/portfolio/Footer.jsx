import React from "react";
import { Mail, Phone, Linkedin, Github, ArrowUp } from "lucide-react";
import { profile, navLinks } from "../../data/mock";

const Footer = () => {
  return (
    <footer className="bg-[#161616] text-[#e5e0d6] pt-16 pb-8 mt-10">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid md:grid-cols-12 gap-10">
          <div className="md:col-span-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center font-serif font-semibold">
                HP
              </div>
              <div className="font-serif text-xl">{profile.name}</div>
            </div>
            <p className="mt-4 text-sm text-[#b8b8b8] max-w-sm leading-relaxed">
              {profile.primaryTitle} &amp; {profile.secondaryTitle}. Based in {profile.location}. Open to on-site, hybrid and remote roles across the U.S.
            </p>
          </div>

          <div className="md:col-span-3">
            <div className="eyebrow text-[#faf8f4]">Navigate</div>
            <ul className="mt-4 space-y-2 text-sm">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-[#b8b8b8] hover:text-[#faf8f4] transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <div className="eyebrow text-[#faf8f4]">Direct Contact</div>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a href={`mailto:${profile.contact.email}`} className="flex items-center gap-2 hover:text-[#faf8f4]">
                  <Mail className="w-4 h-4" /> {profile.contact.email}
                </a>
              </li>
              <li>
                <a href={`tel:${profile.contact.phone}`} className="flex items-center gap-2 hover:text-[#faf8f4]">
                  <Phone className="w-4 h-4" /> {profile.contact.phone}
                </a>
              </li>
              <li>
                <a href={profile.contact.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#faf8f4]">
                  <Linkedin className="w-4 h-4" /> LinkedIn
                </a>
              </li>
              <li>
                <a href={profile.contact.github} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#faf8f4]">
                  <Github className="w-4 h-4" /> GitHub
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[#2a2a2a] flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-xs text-[#8a8a8a] mono tracking-wider">
            © {new Date().getFullYear()} {profile.name}. Crafted with care.
          </div>
          <a href="#top" className="flex items-center gap-2 text-xs text-[#b8b8b8] hover:text-[#faf8f4] mono uppercase tracking-widest">
            Back to top <ArrowUp className="w-3 h-3" />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

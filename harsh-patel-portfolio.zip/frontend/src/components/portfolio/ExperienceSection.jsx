import React from "react";
import { itExperience, devExperience } from "../../data/mock";
import { Briefcase, MapPin, Calendar } from "lucide-react";
import { Badge } from "../ui/badge";

const ExperienceSection = ({ variant = "it" }) => {
  const isIT = variant === "it";
  const items = isIT ? itExperience : devExperience;
  const eyebrow = isIT ? "03 — Professional Experience" : "07 — Professional Experience";
  const title = isIT ? "IT Support Experience" : "Web Development Experience";
  const sectionId = isIT ? "experience" : "dev-experience";
  const bg = isIT ? "bg-[#faf8f4]" : "bg-[#f2efe8] border-y border-[#e5e0d6]";

  return (
    <section id={sectionId} className={`py-20 lg:py-28 ${bg}`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">{eyebrow}</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            {title}
          </h2>
        </div>

        <div className="mt-12 space-y-10">
          {items.map((job, idx) => (
            <div key={job.company} className="fade-in grid lg:grid-cols-12 gap-6">
              {/* Side meta */}
              <div className="lg:col-span-4">
                <div className="flex items-center gap-2 text-[13px] mono uppercase tracking-widest text-[#1e3a5f]">
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>Role {String(idx + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="mt-2 font-serif text-2xl text-[#161616]">{job.role}</h3>
                <div className="mt-1 text-[17px] text-[#1e3a5f] font-medium">{job.company}</div>
                <div className="mt-3 space-y-1 text-sm text-[#6b6b6b]">
                  <div className="flex items-center gap-2"><Calendar className="w-3.5 h-3.5" /> {job.period}</div>
                  <div className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5" /> {job.location}</div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {job.stack.map((t) => (
                    <Badge key={t} variant="outline" className="border-[#d4cfc0] text-[#3a3a3a] bg-white font-normal rounded-sm text-[11px] uppercase tracking-wider mono">
                      {t}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Bullets */}
              <div className="lg:col-span-8 bg-white border border-[#e0dcd2] rounded-sm p-7">
                <ul className="space-y-3">
                  {job.bullets.map((b, i) => (
                    <li key={i} className="text-[15px] leading-[1.75] text-[#3a3a3a] flex gap-3">
                      <span className="text-[#1e3a5f] mono text-xs mt-[5px]">&#9656;</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
                {job.impact && (
                  <div className="mt-6 grid grid-cols-3 gap-3 pt-6 border-t border-[#eeeadf]">
                    {job.impact.map((m) => (
                      <div key={m.label} className="text-center">
                        <div className="font-serif text-2xl text-[#1e3a5f]">{m.metric}</div>
                        <div className="text-[11px] mono uppercase tracking-widest text-[#6b6b6b] mt-1">
                          {m.label}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;

import React, { useState } from "react";
import { Mail, Phone, Linkedin, Github, MapPin, Send, CheckCircle2, Copy } from "lucide-react";
import { profile } from "../../data/mock";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { useToast } from "../../hooks/use-toast";

const RECIPIENT = "hp0413174@gmail.com";

const Contact = () => {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", company: "", message: "", website: "" });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const buildMailto = () => {
    const subject = `Portfolio contact: ${form.name}${form.company ? ` (${form.company})` : ""}`;
    const body =
      `Hi Harsh,\n\n` +
      `My name is ${form.name} and I'm reaching out about an opportunity.\n\n` +
      `\u2500 My details \u2500\n` +
      `Name:    ${form.name}\n` +
      `Email:   ${form.email}\n` +
      `Company: ${form.company || "\u2014"}\n\n` +
      `\u2500 Message \u2500\n` +
      `${form.message}\n\n` +
      `\u2014 Sent from your portfolio contact form`;
    return `mailto:${RECIPIENT}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const onSubmit = (e) => {
    e.preventDefault();

    // Honeypot \u2014 silent exit if triggered
    if (form.website) {
      setSent(true);
      return;
    }

    if (!form.name || !form.email || !form.message) {
      toast({
        title: "Missing fields",
        description: "Please fill in name, email and a message.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    // Open the user's default email client with everything pre-filled
    window.location.href = buildMailto();

    // Give a brief beat for the email client to open, then reset UI
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      toast({
        title: "Opening your email app",
        description:
          "Your message is pre-filled. Just hit Send in your email client and it will arrive in Harsh's inbox.",
      });
      setTimeout(() => setSent(false), 4500);
    }, 500);
  };

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(RECIPIENT);
      toast({ title: "Email copied", description: `${RECIPIENT} is now on your clipboard.` });
    } catch {
      toast({ title: "Copy failed", description: "Please copy the email manually.", variant: "destructive" });
    }
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#161616] text-[#e5e0d6]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <div className="mono text-xs tracking-[0.18em] uppercase text-[#8ca9c9]">
              11 &mdash; Let&rsquo;s Connect
            </div>
            <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#faf8f4]">
              Hiring for IT Support or Web Development?
            </h2>
            <div className="w-16 h-[2px] bg-[#8ca9c9] mt-4"></div>
            <p className="mt-6 text-[16px] leading-[1.8] text-[#b8b8b8]">
              I&apos;m actively interviewing for Tier I / Tier II IT Support, Help Desk, Systems
              Administrator and Front-End Developer roles. Whether you need a reliable first
              responder for your users or a developer who ships polished UIs, let&rsquo;s talk.
            </p>

            <ul className="mt-8 space-y-4">
              <li>
                <a href={`mailto:${profile.contact.email}`} className="flex items-center gap-3 hover:text-[#faf8f4] group">
                  <span className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                    <Mail className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="mono text-[10px] uppercase tracking-widest text-[#8a8a8a]">Email</div>
                    <div className="text-[15px]">{profile.contact.email}</div>
                  </div>
                </a>
              </li>
              <li>
                <a href={`tel:${profile.contact.phone}`} className="flex items-center gap-3 hover:text-[#faf8f4]">
                  <span className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                    <Phone className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="mono text-[10px] uppercase tracking-widest text-[#8a8a8a]">Phone</div>
                    <div className="text-[15px]">{profile.contact.phone}</div>
                  </div>
                </a>
              </li>
              <li>
                <a href={profile.contact.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:text-[#faf8f4]">
                  <span className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                    <Linkedin className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="mono text-[10px] uppercase tracking-widest text-[#8a8a8a]">LinkedIn</div>
                    <div className="text-[15px]">linkedin.com/in/harsh-patel-b815a22b2</div>
                  </div>
                </a>
              </li>
              <li>
                <a href={profile.contact.github} target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:text-[#faf8f4]">
                  <span className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                    <Github className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="mono text-[10px] uppercase tracking-widest text-[#8a8a8a]">GitHub</div>
                    <div className="text-[15px]">github.com/hp0413174-harsh</div>
                  </div>
                </a>
              </li>
              <li className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-sm bg-[#faf8f4] text-[#1e3a5f] flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </span>
                <div>
                  <div className="mono text-[10px] uppercase tracking-widest text-[#8a8a8a]">Location</div>
                  <div className="text-[15px]">{profile.location}</div>
                </div>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-7">
            <form
              onSubmit={onSubmit}
              className="bg-[#1f1f1f] border border-[#2a2a2a] rounded-sm p-7 lg:p-10"
            >
              {/* Honeypot \u2014 hidden from humans, filled by bots */}
              <input
                type="text"
                name="website"
                value={form.website}
                onChange={onChange}
                tabIndex={-1}
                autoComplete="off"
                aria-hidden="true"
                style={{ position: "absolute", left: "-9999px", width: "1px", height: "1px", opacity: 0 }}
              />
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <Label htmlFor="name" className="text-[#b8b8b8] text-xs mono uppercase tracking-widest">
                    Full Name <span className="text-[#f28b82]">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={form.name}
                    onChange={onChange}
                    placeholder="Jane Recruiter"
                    className="mt-2 bg-[#161616] border-[#2a2a2a] text-[#faf8f4] rounded-sm focus-visible:ring-0 focus-visible:border-[#8ca9c9] h-11"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-[#b8b8b8] text-xs mono uppercase tracking-widest">
                    Email <span className="text-[#f28b82]">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={onChange}
                    placeholder="jane@company.com"
                    className="mt-2 bg-[#161616] border-[#2a2a2a] text-[#faf8f4] rounded-sm focus-visible:ring-0 focus-visible:border-[#8ca9c9] h-11"
                  />
                </div>
              </div>

              <div className="mt-5">
                <Label htmlFor="company" className="text-[#b8b8b8] text-xs mono uppercase tracking-widest">
                  Company / Role
                </Label>
                <Input
                  id="company"
                  name="company"
                  value={form.company}
                  onChange={onChange}
                  placeholder="Acme Corp — IT Support Tier II"
                  className="mt-2 bg-[#161616] border-[#2a2a2a] text-[#faf8f4] rounded-sm focus-visible:ring-0 focus-visible:border-[#8ca9c9] h-11"
                />
              </div>

              <div className="mt-5">
                <Label htmlFor="message" className="text-[#b8b8b8] text-xs mono uppercase tracking-widest">
                  Message <span className="text-[#f28b82]">*</span>
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  value={form.message}
                  onChange={onChange}
                  placeholder="Tell me about the role, team and timeline..."
                  rows={6}
                  className="mt-2 bg-[#161616] border-[#2a2a2a] text-[#faf8f4] rounded-sm focus-visible:ring-0 focus-visible:border-[#8ca9c9]"
                />
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
                <div className="text-xs text-[#8a8a8a] mono leading-relaxed">
                  Opens your email app with everything pre-filled.<br />
                  No mail client?{" "}
                  <button
                    type="button"
                    onClick={copyEmail}
                    className="underline decoration-dotted underline-offset-2 hover:text-[#faf8f4] inline-flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> copy email
                  </button>
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="bg-[#faf8f4] hover:bg-[#e5e0d6] text-[#161616] rounded-sm h-11 px-6"
                >
                  {sent ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 mr-2" /> Email App Opened
                    </>
                  ) : (
                    <>
                      {loading ? "Opening..." : "Send Message"} <Send className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;

import React, { useState, useEffect } from "react";
import { Menu, X, Download } from "lucide-react";
import { navLinks, profile } from "../../data/mock";
import { Button } from "../ui/button";

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`no-print fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "bg-[#faf8f4]/90 backdrop-blur border-b border-[#e5e0d6]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-[72px] flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-sm bg-[#1e3a5f] text-[#faf8f4] flex items-center justify-center font-serif font-semibold tracking-wider">
            HP
          </div>
          <div className="hidden sm:block leading-tight">
            <div className="font-serif font-semibold text-[#161616]">
              {profile.name}
            </div>
            <div className="text-[11px] tracking-widest uppercase text-[#6b6b6b] mono">
              IT &middot; Web
            </div>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-7">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm text-[#3a3a3a] hover:text-[#1e3a5f] transition-colors duration-200"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button
            asChild
            className="hidden sm:inline-flex bg-[#1e3a5f] hover:bg-[#132841] text-[#faf8f4] rounded-sm h-10 px-4"
          >
            <a href={profile.contact.resumeUrl} download="Harsh_Patel_Resume.pdf" target="_blank" rel="noreferrer">
              <Download className="w-4 h-4 mr-2" /> Resume
            </a>
          </Button>
          <button
            className="lg:hidden w-10 h-10 rounded-sm border border-[#e0dcd2] flex items-center justify-center"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-[#faf8f4] border-t border-[#e5e0d6]">
          <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="text-[#3a3a3a] py-2 border-b border-[#eeeadf] hover:text-[#1e3a5f]"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;

import React from "react";
import { Headphones, ShieldCheck, Network, HardDrive, Check } from "lucide-react";
import { itSkillCategories } from "../../data/mock";

const iconMap = { Headphones, ShieldCheck, Network, HardDrive };

const ITSkills = () => {
  return (
    <section id="it-support" className="py-20 lg:py-28 bg-[#f2efe8] border-y border-[#e5e0d6]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">02 &mdash; Primary Specialization</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            IT Support & Infrastructure
          </h2>
          <p className="mt-5 text-[17px] leading-[1.8] text-[#3a3a3a]">
            Reliable, SLA-driven Help Desk operations for Tier I and Tier II roles — from hardware
            and network troubleshooting to Active Directory, Microsoft 365 and security-hardening
            best practices.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-6">
          {itSkillCategories.map((cat) => {
            const Icon = iconMap[cat.icon] || Headphones;
            return (
              <div
                key={cat.title}
                className="fade-in bg-[#faf8f4] border border-[#e0dcd2] p-7 rounded-sm hover:border-[#1e3a5f] transition-colors duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-sm bg-[#1e3a5f] text-[#faf8f4] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-serif text-xl text-[#161616]">{cat.title}</h3>
                    <ul className="mt-4 space-y-2.5">
                      {cat.skills.map((s) => (
                        <li key={s} className="flex items-start gap-2.5 text-[15px] text-[#3a3a3a]">
                          <Check className="w-4 h-4 text-[#1e3a5f] mt-[3px] shrink-0" />
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ITSkills;

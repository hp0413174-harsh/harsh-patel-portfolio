import React from "react";
import { itProjects } from "../../data/mock";
import { Server, Check } from "lucide-react";
import { Badge } from "../ui/badge";

const ITProjects = () => {
  return (
    <section id="it-projects" className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">04 &mdash; IT Projects</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            Help Desk & Infrastructure Projects
          </h2>
          <p className="mt-5 text-[17px] leading-[1.8] text-[#3a3a3a]">
            Real-world scenarios where I owned the problem end-to-end — from ticket triage to
            documentation, rollout and hardening.
          </p>
        </div>

        <div className="mt-12 grid lg:grid-cols-3 gap-6">
          {itProjects.map((p) => (
            <article
              key={p.title}
              className="fade-in bg-[#faf8f4] border border-[#e0dcd2] rounded-sm p-7 flex flex-col hover:border-[#1e3a5f] hover:shadow-[0_10px_30px_-15px_rgba(30,58,95,0.25)] transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-sm bg-[#161616] text-[#faf8f4] flex items-center justify-center">
                <Server className="w-5 h-5" />
              </div>
              <h3 className="mt-5 font-serif text-xl text-[#161616] leading-tight">{p.title}</h3>
              <p className="mt-1 text-sm text-[#6b6b6b]">{p.subtitle}</p>

              <ul className="mt-5 space-y-2.5 flex-1">
                {p.bullets.map((b, i) => (
                  <li key={i} className="flex gap-2.5 text-[14px] text-[#3a3a3a] leading-relaxed">
                    <Check className="w-4 h-4 text-[#1e3a5f] mt-[2px] shrink-0" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-6 pt-5 border-t border-[#eeeadf] flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <Badge key={t} variant="outline" className="border-[#d4cfc0] text-[#3a3a3a] bg-white font-normal rounded-sm text-[11px] uppercase tracking-wider mono">
                    {t}
                  </Badge>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ITProjects;

import React from "react";
import { keywordBar } from "../../data/mock";

const KeywordBar = () => {
  const loop = [...keywordBar, ...keywordBar];
  return (
    <section aria-label="Key skills keywords" className="border-y border-[#e5e0d6] bg-[#f2efe8] overflow-hidden">
      <div className="relative py-4">
        <div className="flex gap-10 whitespace-nowrap animate-marquee">
          {loop.map((k, i) => (
            <span key={i} className="mono text-xs tracking-widest uppercase text-[#3a3a3a] flex items-center gap-10">
              {k}
              <span className="w-1 h-1 rounded-full bg-[#1e3a5f]"></span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeywordBar;

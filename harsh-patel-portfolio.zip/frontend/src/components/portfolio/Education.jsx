import React from "react";
import { education } from "../../data/mock";
import { GraduationCap, MapPin } from "lucide-react";

const Education = () => {
  return (
    <section id="education" className="py-20 lg:py-28 bg-[#f2efe8] border-y border-[#e5e0d6]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 fade-in">
            <div className="eyebrow">09 &mdash; Education</div>
            <h2 className="mt-3 font-serif text-3xl sm:text-4xl text-[#161616] ornamental-line">
              Academic Background
            </h2>
            <p className="mt-5 text-[15px] leading-relaxed text-[#6b6b6b]">
              Graduate-level training in Information Systems complemented by an undergraduate
              foundation in Information Technology.
            </p>
          </div>

          <div className="lg:col-span-8 space-y-5">
            {education.map((e) => (
              <div
                key={e.school}
                className="fade-in bg-[#faf8f4] border border-[#e0dcd2] rounded-sm p-7 flex gap-5 hover:border-[#1e3a5f] transition-colors duration-300"
              >
                <div className="w-12 h-12 rounded-sm bg-[#1e3a5f] text-[#faf8f4] flex items-center justify-center shrink-0">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="font-serif text-xl text-[#161616]">{e.school}</h3>
                    <div className="mono text-xs uppercase tracking-widest text-[#1e3a5f]">
                      {e.period}
                    </div>
                  </div>
                  <div className="mt-1 text-[#1e3a5f] font-medium">{e.degree}</div>
                  <div className="mt-1 text-sm text-[#6b6b6b] flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5" /> {e.location}
                  </div>
                  <p className="mt-3 text-[14px] leading-relaxed text-[#3a3a3a]">{e.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;

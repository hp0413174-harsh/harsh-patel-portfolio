import React from "react";
import { Code2, Server, PenTool, Wrench, Check } from "lucide-react";
import { devSkillCategories } from "../../data/mock";

const iconMap = { Code2, Server, PenTool, Wrench };

const DevSkills = () => {
  return (
    <section id="web-development" className="py-20 lg:py-28 bg-[#faf8f4]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">06 &mdash; Secondary Specialization</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            Web Development & UI/UX
          </h2>
          <p className="mt-5 text-[17px] leading-[1.8] text-[#3a3a3a]">
            Full front-end engineering capability complementing the IT skill set — building
            accessible, responsive, and production-ready web applications, design systems, and
            REST-backed experiences.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-6">
          {devSkillCategories.map((cat) => {
            const Icon = iconMap[cat.icon] || Code2;
            return (
              <div
                key={cat.title}
                className="fade-in bg-white border border-[#e0dcd2] p-7 rounded-sm hover:border-[#1e3a5f] transition-colors duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-sm bg-[#1e3a5f] text-[#faf8f4] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-serif text-xl text-[#161616]">{cat.title}</h3>
                    <ul className="mt-4 space-y-2.5">
                      {cat.skills.map((s) => (
                        <li key={s} className="flex items-start gap-2.5 text-[15px] text-[#3a3a3a]">
                          <Check className="w-4 h-4 text-[#1e3a5f] mt-[3px] shrink-0" />
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default DevSkills;

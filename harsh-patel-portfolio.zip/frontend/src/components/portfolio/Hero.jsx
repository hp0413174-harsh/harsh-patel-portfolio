import React from "react";
import { MapPin, Mail, Phone, Linkedin, Github, ArrowRight, Download, CheckCircle2 } from "lucide-react";
import { profile, heroStats } from "../../data/mock";
import { Button } from "../ui/button";

const Hero = () => {
  return (
    <section id="top" className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 paper-texture">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* Text */}
          <div className="lg:col-span-7 order-2 lg:order-1">
            <div className="eyebrow mb-5">Available for hire &middot; {profile.location}</div>
            <h1 className="font-serif text-[40px] sm:text-5xl lg:text-6xl leading-[1.05] tracking-tight text-[#161616]">
              {profile.firstName}{" "}
              <span className="text-[#1e3a5f]">{profile.lastName}</span>
              <span className="block text-[#3a3a3a] text-[26px] sm:text-3xl lg:text-4xl mt-4 font-normal">
                {profile.primaryTitle}
                <span className="text-[#8a8a8a]"> &nbsp;/&nbsp; </span>
                {profile.secondaryTitle}
              </span>
            </h1>

            <p className="mt-6 text-[17px] leading-relaxed text-[#3a3a3a] max-w-2xl">
              {profile.headline}
            </p>

            <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-[#3a3a3a]">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1e3a5f]" /> {profile.authorization}
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1e3a5f]" /> {profile.availability}
              </li>
            </ul>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button
                asChild
                className="bg-[#1e3a5f] hover:bg-[#132841] text-[#faf8f4] h-12 px-6 rounded-sm text-[15px]"
              >
                <a href="#contact">
                  Hire Me <ArrowRight className="w-4 h-4 ml-2" />
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                className="border-[#1e3a5f] text-[#1e3a5f] hover:bg-[#1e3a5f] hover:text-[#faf8f4] h-12 px-6 rounded-sm text-[15px] bg-transparent"
              >
                <a href={profile.contact.resumeUrl} download="Harsh_Patel_Resume.pdf" target="_blank" rel="noreferrer">
                  <Download className="w-4 h-4 mr-2" /> Download Resume
                </a>
              </Button>
            </div>

            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-[#3a3a3a]">
              <a href={`mailto:${profile.contact.email}`} className="flex items-center gap-2 hover:text-[#1e3a5f] transition-colors">
                <Mail className="w-4 h-4" /> {profile.contact.email}
              </a>
              <a href={`tel:${profile.contact.phone}`} className="flex items-center gap-2 hover:text-[#1e3a5f] transition-colors">
                <Phone className="w-4 h-4" /> {profile.contact.phone}
              </a>
              <a href={profile.contact.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#1e3a5f] transition-colors">
                <Linkedin className="w-4 h-4" /> LinkedIn
              </a>
              <a href={profile.contact.github} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#1e3a5f] transition-colors">
                <Github className="w-4 h-4" /> GitHub
              </a>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" /> {profile.location}
              </div>
            </div>
          </div>

          {/* Photo + stats card */}
          <div className="lg:col-span-5 order-1 lg:order-2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-full h-full border border-[#1e3a5f] rounded-sm hidden sm:block"></div>
              <div className="relative bg-white rounded-sm overflow-hidden shadow-[0_20px_50px_-20px_rgba(30,58,95,0.25)]">
                <img
                  src={profile.photo}
                  alt={`${profile.name} — ${profile.primaryTitle}`}
                  className="w-full h-[520px] object-cover object-[center_18%] grayscale-[15%]"
                />
                <div className="grid grid-cols-4 bg-[#161616] text-[#faf8f4]">
                  {heroStats.map((s) => (
                    <div key={s.label} className="text-center py-4 px-2 border-r last:border-r-0 border-[#2a2a2a]">
                      <div className="font-serif text-xl sm:text-2xl font-semibold">{s.value}</div>
                      <div className="text-[10px] tracking-widest uppercase text-[#b8b8b8] mono mt-1 leading-tight">
                        {s.label}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

import React from "react";
import { testimonials } from "../../data/mock";
import { Quote } from "lucide-react";

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="max-w-3xl fade-in">
          <div className="eyebrow">10 &mdash; Social Proof</div>
          <h2 className="mt-3 font-serif text-3xl sm:text-4xl lg:text-5xl text-[#161616] ornamental-line">
            What Colleagues Say
          </h2>
        </div>

        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <figure
              key={i}
              className="fade-in bg-[#faf8f4] border border-[#e0dcd2] rounded-sm p-7 flex flex-col"
            >
              <Quote className="w-7 h-7 text-[#1e3a5f]" />
              <blockquote className="mt-4 text-[15px] leading-relaxed text-[#3a3a3a] flex-1">
                “{t.quote}”
              </blockquote>
              <figcaption className="mt-6 pt-5 border-t border-[#eeeadf]">
                <div className="font-medium text-[#161616]">{t.author}</div>
                <div className="text-xs mono uppercase tracking-widest text-[#6b6b6b] mt-1">
                  {t.role}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

import React from "react";
import { profile } from "../../data/mock";

const About = () => {
  return (
    <section id="about" className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 fade-in">
            <div className="eyebrow">01 &mdash; Profile</div>
            <h2 className="mt-3 font-serif text-3xl sm:text-4xl text-[#161616] ornamental-line">
              About Harsh
            </h2>
          </div>
          <div className="lg:col-span-8 fade-in">
            <p className="text-[17px] leading-[1.8] text-[#3a3a3a]">
              {profile.summary}
            </p>
            <div className="mt-8 grid sm:grid-cols-3 gap-6">
              <div className="border-l-2 border-[#1e3a5f] pl-4">
                <div className="eyebrow">Primary focus</div>
                <div className="mt-1 font-medium text-[#161616]">IT Support Tier I / II</div>
                <div className="text-sm text-[#6b6b6b] mt-1">Help Desk, AD, M365, Networking</div>
              </div>
              <div className="border-l-2 border-[#1e3a5f] pl-4">
                <div className="eyebrow">Secondary focus</div>
                <div className="mt-1 font-medium text-[#161616]">Web Development</div>
                <div className="text-sm text-[#6b6b6b] mt-1">React, Node, UI/UX, Accessibility</div>
              </div>
              <div className="border-l-2 border-[#1e3a5f] pl-4">
                <div className="eyebrow">Education</div>
                <div className="mt-1 font-medium text-[#161616]">M.S. Information Systems</div>
                <div className="text-sm text-[#6b6b6b] mt-1">Cleveland State University</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

// Mock data for Harsh Patel's Portfolio
// All content here is frontend mock. Backend integration will replace contact form submission.

export const profile = {
  name: "Harsh Patel",
  firstName: "Harsh",
  lastName: "Patel",
  primaryTitle: "IT Support Specialist",
  secondaryTitle: "Web Developer & UI/UX Engineer",
  headline:
    "IT Support Specialist (Tier I / Tier II) & Web Developer with 5+ years delivering reliable infrastructure, rapid ticket resolution, and production-ready web applications.",
  location: "Cleveland, Ohio, USA",
  availability: "Open to Full-time, Hybrid & Remote roles across the U.S.",
  authorization: "Authorized to work in the U.S.",
  photo:
    "https://customer-assets.emergentagent.com/job_98f7d97c-df42-4195-b8d4-d3e84f3c1ec1/artifacts/nhs8kj41_Harsh%20Photo.jpeg",
  summary:
    "Versatile IT professional with 5+ years of combined experience across Help Desk Operations, Network Administration, and Full-Stack Web Development. Master's degree in Information Systems from Cleveland State University. Proven ability to troubleshoot hardware, software and network issues end-to-end, administer Active Directory and Microsoft 365, and deliver secure, accessible, high-performance web applications. Recognized for reducing incident response time by 20% and maintaining 99% uptime across business-critical infrastructure.",
  contact: {
    phone: "+1 (216) 551-1536",
    email: "hp0413174@gmail.com",
    linkedin: "https://www.linkedin.com/in/harsh-patel-b815a22b2/",
    github: "https://github.com/hp0413174-harsh",
    resumeUrl: `${process.env.PUBLIC_URL || ""}/Harsh_Patel_Resume.pdf`,
  },
};

export const heroStats = [
  { value: "5+", label: "Years in IT" },
  { value: "99%", label: "Infra Uptime" },
  { value: "20%", label: "Faster Ticket Resolution" },
  { value: "300+", label: "UI / Web Projects" },
];

export const keywordBar = [
  "Help Desk",
  "Tier I & II Support",
  "Active Directory",
  "Microsoft 365",
  "Windows / macOS",
  "LAN / WAN / TCP-IP",
  "Ticketing Systems",
  "ITIL",
  "Remote Support",
  "Hardware Troubleshooting",
  "Network Configuration",
  "Firewall & Security",
  "SOP Documentation",
  "React.js",
  "JavaScript (ES6+)",
  "HTML5 / CSS3",
  "Node.js",
  "REST APIs",
  "Git / GitHub",
  "Agile / Scrum",
];

// =====================  IT SUPPORT (TOP)  =====================
export const itSkillCategories = [
  {
    title: "Help Desk & End-User Support",
    icon: "Headphones",
    skills: [
      "Tier I & Tier II technical support",
      "Incident logging, triage & escalation",
      "Ticketing systems (ServiceNow, Jira, Zendesk)",
      "SLA compliance & queue management",
      "Remote desktop support (TeamViewer, AnyDesk, RDP)",
      "White-glove support for executives",
    ],
  },
  {
    title: "Systems & Identity Administration",
    icon: "ShieldCheck",
    skills: [
      "Active Directory (users, groups, OUs, GPOs)",
      "Microsoft 365 / Exchange Online administration",
      "User provisioning & access controls (RBAC)",
      "Windows 10 / 11 & macOS imaging and deployment",
      "Endpoint management & patch cycles",
      "Password & MFA policy enforcement",
    ],
  },
  {
    title: "Networking & Infrastructure",
    icon: "Network",
    skills: [
      "LAN / WAN & TCP/IP configuration",
      "Router, switch & wireless AP setup",
      "DNS, DHCP & VPN administration",
      "Firewall rules & VLAN segmentation",
      "Network printers & peripherals",
      "Cable management & structured wiring",
    ],
  },
  {
    title: "Hardware, Software & Security",
    icon: "HardDrive",
    skills: [
      "PC / laptop hardware diagnostics & repair",
      "OS installation, drivers & BIOS/UEFI",
      "Antivirus, EDR & endpoint hardening",
      "Data backup, recovery & migration",
      "Root-cause analysis on recurring failures",
      "IT asset inventory & lifecycle tracking",
    ],
  },
];

export const itExperience = [
  {
    company: "Patel Battery House Pvt. Ltd.",
    role: "Network Administrator / IT Support Specialist",
    period: "Jul 2022 – Jul 2023",
    location: "Gujarat, India",
    stack: ["Active Directory", "O365", "LAN/WAN", "Firewalls", "Windows Server"],
    bullets: [
      "Front-line Tier I/II support for 80+ end users across hardware, software and networking issues, resolving an average of 25 tickets per day within SLA.",
      "Managed LAN/WAN infrastructure — installed and configured routers, switches, access points and network printers; maintained a full IT asset inventory.",
      "Administered Active Directory and Microsoft 365: user provisioning, group policies, shared mailboxes and access-level controls.",
      "Implemented firewall rules and user access controls, strengthening the company's security posture and protecting corporate data from unauthorized access.",
      "Authored SOP documentation and knowledge-base articles, cutting average ticket response time by 20% and reducing repeat incidents.",
      "Delivered white-glove technical support for executive leadership and conducted root-cause analysis on recurring system failures.",
    ],
    impact: [
      { metric: "99%", label: "Infrastructure uptime" },
      { metric: "-20%", label: "Ticket response time" },
      { metric: "80+", label: "End users supported" },
    ],
  },
];

export const itProjects = [
  {
    title: "IT Service Management & Ticketing Simulation",
    subtitle: "End-to-end Help Desk lifecycle",
    tags: ["ITIL", "Ticketing", "SLA", "Knowledge Base"],
    bullets: [
      "Supervised the full incident lifecycle — from logging and categorization to root-cause analysis and resolution.",
      "Monitored queues to maintain SLA compliance for response and resolution times, preventing breaches.",
      "Authored SOPs and 'How-To' guides for the self-service Knowledge Base, reducing repeat tickets.",
      "Translated technical fixes into plain-English communications for non-technical users.",
    ],
  },
  {
    title: "Windows 11 Fleet Rollout & AD Hardening",
    subtitle: "Imaging, GPOs & security baseline",
    tags: ["Windows 11", "AD", "GPO", "MDT"],
    bullets: [
      "Designed a standardized Windows 11 image with MDT for rapid provisioning of new workstations.",
      "Deployed Group Policy Objects to enforce password, screen-lock and USB policies organization-wide.",
      "Documented the rollback plan and verified compatibility with line-of-business applications.",
    ],
  },
  {
    title: "Microsoft 365 Migration & MFA Enablement",
    subtitle: "Mailbox migration with zero downtime",
    tags: ["M365", "Exchange", "MFA", "Security"],
    bullets: [
      "Planned and executed mailbox migration to Exchange Online with zero user downtime during cutover.",
      "Rolled out Multi-Factor Authentication and conditional-access policies across the tenant.",
      "Trained staff on the new sign-in experience and built a quick-reference troubleshooting guide.",
    ],
  },
];

export const certifications = [
  { name: "CompTIA A+", status: "In Progress", issuer: "CompTIA" },
  { name: "CompTIA Network+", status: "In Progress", issuer: "CompTIA" },
  { name: "Google UX Design Professional Certificate", status: "In Progress", issuer: "Google / Coursera" },
  { name: "IBM Front-End Developer Certificate", status: "In Progress", issuer: "IBM / Coursera" },
  { name: "Web Designer Certification", status: "Completed", issuer: "Creart Solutions" },
  { name: "ITIL 4 Foundation", status: "Planned", issuer: "AXELOS" },
];

// =====================  WEB DEVELOPMENT (BOTTOM)  =====================
export const devSkillCategories = [
  {
    title: "Frontend Development",
    icon: "Code2",
    skills: [
      "HTML5, CSS3, SCSS, JavaScript (ES6+)",
      "React.js, Angular, Next.js",
      "Tailwind CSS, Bootstrap 5, Material UI",
      "Responsive & Mobile-first design",
      "WCAG 2.1 / ADA accessibility",
      "Cross-browser compatibility",
    ],
  },
  {
    title: "Backend & APIs",
    icon: "Server",
    skills: [
      "Node.js & Express (REST APIs)",
      "PHP, Python basics",
      "Authentication & session management",
      "MongoDB, MySQL",
      "API integration & error handling",
      "CI/CD with GitHub Actions",
    ],
  },
  {
    title: "UI/UX & Design Systems",
    icon: "PenTool",
    skills: [
      "Figma, Adobe XD, Sketch",
      "Wireframing & hi-fi prototyping",
      "Design systems & component libraries",
      "User research, personas, journey maps",
      "Usability testing & A/B testing",
      "Heuristic evaluation & UX audits",
    ],
  },
  {
    title: "Tooling & Workflow",
    icon: "Wrench",
    skills: [
      "Git & GitHub (branching, PR reviews)",
      "Agile / Scrum, Jira, Confluence",
      "Jest, Cypress automated testing",
      "Netlify, Vercel deployment",
      "Performance & Lighthouse tuning",
      "Code splitting & lazy loading",
    ],
  },
];

export const devExperience = [
  {
    company: "Quantumwave Infotech LLC",
    role: "UI/UX Designer & Front-End Developer",
    period: "Aug 2025 – Present",
    location: "Cleveland, OH (Hybrid)",
    stack: ["React", "Figma", "Design Systems", "WCAG", "Agile"],
    bullets: [
      "Conducted end-to-end user research, interviews and usability testing — improving user-satisfaction scores by 32% through data-driven design enhancements.",
      "Designed wireframes, interactive prototypes and user flows in Figma, reducing design-iteration cycles by 28% and accelerating product release timelines.",
      "Built responsive web and mobile UIs aligned to brand guidelines, increasing user engagement and average session duration by 35%.",
      "Partnered with product managers and engineers to align UX strategy with business goals, cutting rework and development friction by 25%.",
      "Enforced WCAG 2.1 accessibility standards, raising enterprise accessibility compliance by 40%.",
      "Built and maintained scalable design systems and reusable UI components, reducing development effort by 30%.",
    ],
  },
  {
    company: "Creart Solutions",
    role: "UI/UX Designer & Front-End Developer",
    period: "Jun 2019 – Jul 2022",
    location: "Ahmedabad, India",
    stack: ["Figma", "React", "Adobe XD", "SCSS", "Bootstrap"],
    bullets: [
      "Delivered 300+ wireframes and interactive prototypes across banking, security and education domains — earning quarterly recognition for design excellence.",
      "Performed UX audits on web and mobile platforms, identifying navigation gaps and shipping optimizations that improved task completion.",
      "Built and maintained comprehensive style guides covering typography, color and interaction principles for consistent brand identity.",
      "Designed motion graphics and micro-interactions that enriched user engagement across client portfolios.",
      "Collaborated with cross-functional teams and clients to gather requirements and iterate on design solutions, strengthening delivery timelines.",
    ],
  },
];

export const devProjects = [
  {
    title: "E-Commerce Platform",
    subtitle: "Full-stack shopping experience",
    tags: ["React", "Node.js", "REST APIs", "MongoDB"],
    bullets: [
      "Built REST APIs for dynamic product filtering, cart and order management.",
      "Integrated secure payment flow and authentication with session handling.",
      "Designed a fully responsive UI covering desktop, tablet and mobile breakpoints.",
      "Optimized bundle size and load time for a 25% faster first-contentful-paint.",
    ],
  },
  {
    title: "Healthcare Booking Portal",
    subtitle: "Real-time appointment scheduling",
    tags: ["React", "Bootstrap", "Jest", "ADA"],
    bullets: [
      "Built with React.js, HTML5, CSS3 and Bootstrap for full-device responsiveness.",
      "Integrated real-time availability and authenticated user management APIs.",
      "Designed ADA-compliant Figma UI and verified reliability with Jest unit tests.",
      "Improved end-to-end booking efficiency by 35%.",
    ],
  },
  {
    title: "Interactive Educational Microsite",
    subtitle: "Single-page e-learning experience",
    tags: ["React", "Redux", "SASS", "Cypress"],
    bullets: [
      "Developed a SPA in React + Redux with captivating interactive course modules.",
      "Reduced load time by 25% through effective asset management and SASS tuning.",
      "Used Cypress for automated end-to-end testing inside an Agile delivery pipeline.",
    ],
  },
];

export const education = [
  {
    school: "Cleveland State University",
    degree: "Master of Science — Information Systems",
    period: "2023 – 2025",
    location: "Cleveland, Ohio, USA",
    detail: "GPA 3.26 / 4.0 — Coursework: Network Security, Systems Analysis, Database Management, IT Project Management.",
  },
  {
    school: "Apollo Institute of Engineering & Technology",
    degree: "Bachelor of Technology — Information Technology",
    period: "2015 – 2019",
    location: "Ahmedabad, India",
    detail: "GPA 3.67 / 4.0 — Networking, Operating Systems, Software Engineering, Web Technologies.",
  },
];

export const testimonials = [
  {
    quote:
      "Harsh consistently owns problems end-to-end. Whether it was an urgent network outage or a redesign sprint, he documented everything cleanly and delivered on time.",
    author: "Reporting Manager",
    role: "IT Operations — Patel Battery House",
  },
  {
    quote:
      "One of the most reliable designers I've worked with. His understanding of both user research and front-end code bridges a gap most teams struggle with.",
    author: "Product Lead",
    role: "Creart Solutions",
  },
  {
    quote:
      "Calm under pressure, strong communicator with non-technical users, and genuinely curious about how systems work. Exactly the profile we look for in Tier II Support.",
    author: "Senior Engineer",
    role: "Peer Review",
  },
];

export const navLinks = [
  { label: "About", href: "#about" },
  { label: "IT Support", href: "#it-support" },
  { label: "Experience", href: "#experience" },
  { label: "Certifications", href: "#certifications" },
  { label: "Web Development", href: "#web-development" },
  { label: "Education", href: "#education" },
  { label: "Contact", href: "#contact" },
];

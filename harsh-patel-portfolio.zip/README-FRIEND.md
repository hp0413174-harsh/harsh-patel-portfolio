# Harsh Patel Portfolio — Quick Deploy Guide

This project is **pre-configured** for GitHub user **`hp0413174-harsh`** with repo
name **`harsh-patel-portfolio`**. You do not need to edit any file — just run the
commands below.

## Prerequisites (one-time, skip anything you already have)

1. **Node.js 18+** — https://nodejs.org → click the green **LTS** button → install.
2. **Git** — https://git-scm.com/downloads → install.
3. **Yarn** — in a terminal run:
   ```bash
   npm install -g yarn
   ```
4. Sign in to GitHub as **`hp0413174-harsh`** (or create it at
   https://github.com/signup if needed).

## Step 1 — Create an empty GitHub repo

1. Go to https://github.com/new while signed in as `hp0413174-harsh`.
2. **Repository name**: `harsh-patel-portfolio` (exactly, lowercase, with dashes).
3. Visibility: **Public**.
4. **Do NOT** check "Add a README" or "Add .gitignore".
5. Click **Create repository**.
6. Keep the tab open — you'll use the URL shown on the next screen:
   `https://github.com/hp0413174-harsh/harsh-patel-portfolio.git`

## Step 2 — Deploy from your computer

Unzip the package anywhere. Open a terminal **inside** the `frontend` folder.

> Mac: right-click the `frontend` folder → *New Terminal at Folder*.
> Windows: Shift + right-click inside `frontend` → *Open PowerShell window here*.

Run these, one at a time:

```bash
# 1. Install dependencies (2–3 minutes)
yarn install

# 2. Connect the folder to GitHub
git init
git add .
git commit -m "initial portfolio"
git branch -M main
git remote add origin https://github.com/hp0413174-harsh/harsh-patel-portfolio.git
git push -u origin main

# 3. Build and publish to GitHub Pages
yarn deploy
```

During `git push`:
- On Mac/Windows a browser pops up to sign in — just log in as `hp0413174-harsh`.
- If the terminal asks for a **password**, paste a **Personal Access Token**
  (create one at https://github.com/settings/tokens — "classic" — check the
  `repo` scope).

When `yarn deploy` finishes you'll see "**Published**".

## Step 3 — Turn on GitHub Pages (30 seconds, one time)

1. Go to https://github.com/hp0413174-harsh/harsh-patel-portfolio
2. Click the **Settings** tab (top of the page).
3. Click **Pages** in the left sidebar.
4. Under **Source** select:
   - Deploy from a branch
   - Branch: **`gh-pages`**
   - Folder: **`/ (root)`**
5. Click **Save**.

Wait 1–2 minutes, then visit the live portfolio:

```
https://hp0413174-harsh.github.io/harsh-patel-portfolio
```

## Future updates

Any time the portfolio needs a change, just run from the `frontend` folder:

```bash
yarn deploy
```

GitHub Pages refreshes automatically within ~60 seconds.

## How the contact form works

It opens the recruiter's own email app (Gmail, Outlook, Apple Mail) pre-filled
with their message, addressed to `hp0413174@gmail.com`. They hit Send inside
their email app and the message arrives. This is why no backend or hosted form
service is required.

## Common issues

| Problem | Fix |
|---|---|
| `yarn` not recognized | Close & reopen the terminal after installing Yarn |
| `git push` asks for a password that never works | Use a Personal Access Token from https://github.com/settings/tokens |
| 404 on the live URL right after deploy | Wait 2 minutes — GitHub Pages takes a moment |
| Resume PDF or CSS looks broken | The repo name must be exactly `harsh-patel-portfolio` (lowercase, hyphens). If you used a different name, edit the `homepage` line in `frontend/package.json` to match. |

## Alternative: drag-and-drop deploy (30 seconds)

If GitHub Pages gives trouble, the pre-built site is already inside the
`frontend/build/` folder. Just drag that folder onto:

> https://app.netlify.com/drop

Netlify returns a public URL instantly. Free forever.
